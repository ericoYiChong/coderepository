const dragList = [{
        "componentId": 9,
        "componentName": "轮播图模块",
        "componentUri": "",
        "componentMax": 10,
        "dragcomponentName": "bannerModel",
        "usedNum": 0,
        "isShowEdit": true
    },
    {
        "componentId": 10,
        "componentName": "单列图片模块",
        "componentUri": "",
        "componentMax": 10,
        "dragcomponentName": "singlePicModel",
        "usedNum": 0,
        "isShowEdit": true
    },
]
export default {
    dragList
}